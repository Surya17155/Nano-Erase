
import React, { useState } from 'react';
import { Key, Lock, ArrowRight, ExternalLink } from 'lucide-react';

interface Props {
  onSubmit: (key: string) => void;
  onCancel: () => void;
}

export const ApiKeyModal: React.FC<Props> = ({ onSubmit, onCancel }) => {
  const [key, setKey] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!key.startsWith('AIza') && key.length < 20) {
      setError('Invalid API Key format. It usually starts with "AIza".');
      return;
    }
    onSubmit(key);
  };

  return (
    <div className="fixed inset-0 z-[5000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={onCancel}></div>
      
      <div className="relative bg-white rounded-[24px] p-8 w-full max-w-md shadow-2xl transform transition-all">
        <div className="flex flex-col items-center text-center gap-4 mb-6">
          <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-2">
            <Key className="w-8 h-8 text-blue-600" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-black">Setup API Key</h2>
            <p className="text-gray-500 mt-2 text-sm leading-relaxed">
              To keep NanoErase free and unlimited, you need to use your own Google Gemini API Key. 
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-start gap-3">
             <Lock className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
             <p className="text-xs text-gray-600 text-left">
               <strong>Security Note:</strong> Your key is encrypted in your browser session and used directly with Google. We do not store it on our servers.
             </p>
          </div>

          <div className="space-y-2">
             <label className="text-xs font-bold uppercase tracking-wider text-gray-400 ml-1">Paste Key Here</label>
             <input 
               type="password" 
               value={key}
               onChange={(e) => { setKey(e.target.value); setError(''); }}
               className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-mono text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all"
               placeholder="AIza..."
             />
             {error && <p className="text-red-500 text-xs font-bold px-1">{error}</p>}
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-black text-white rounded-xl font-bold shadow-lg hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            Save & Continue <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-gray-100 flex justify-center">
           <a 
             href="https://aistudio.google.com/app/apikey" 
             target="_blank" 
             rel="noopener noreferrer"
             className="flex items-center gap-2 text-blue-600 text-sm font-bold hover:underline"
           >
             Get a free API Key <ExternalLink className="w-3 h-3" />
           </a>
        </div>
      </div>
    </div>
  );
};
