
import React, { useState } from 'react';
import { X, AlertCircle, Copy, Check, ShieldAlert, Loader2, UserCircle2 } from 'lucide-react';

interface Props {
  onClose: () => void;
  onGoogleLogin: () => void;
  onEmailLogin: (email: string) => void;
  onGuestLogin?: () => void;
  error?: string | null;
}

export const AuthModal: React.FC<Props> = ({ onClose, onGoogleLogin, onGuestLogin, error }) => {
  // Use lazy initialization to get the domain immediately on mount/render.
  const [currentDomain] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.location.host || window.location.hostname || window.location.origin.replace(/^https?:\/\//, '');
    }
    return '';
  });
  
  const [copied, setCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const copyToClipboard = () => {
    if (!currentDomain) return;
    navigator.clipboard.writeText(currentDomain);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLoginClick = async () => {
    if (isLoading) return;
    setIsLoading(true);
    try {
      await onGoogleLogin();
    } catch (e) {
      setIsLoading(false);
    }
  };

  const isDomainError = error === 'unauthorized-domain';

  return (
    <div className="fixed inset-0 z-[5000] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      ></div>

      {/* Modal Card */}
      <div className="relative bg-[#d9d9d9] rounded-[24px] p-8 w-full max-w-[420px] shadow-2xl border border-white/20">
        
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-black/5 transition-colors"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>

        {/* Content */}
        <div className="flex flex-col gap-6">
          <div className="text-left">
            <h2 className="text-[#2c2c2c] text-2xl font-bold mb-1">Welcome</h2>
            <p className="text-[#666666] font-medium text-sm">Sign in to continue to NanoErase</p>
          </div>

          {/* Critical Error Display for Domain Issues */}
          {isDomainError && (
            <div className="bg-red-50 border-l-4 border-red-500 rounded-r-xl p-4 animate-in fade-in zoom-in-95 shadow-sm">
              <div className="flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="w-full">
                  <h3 className="text-red-800 font-bold text-sm">Action Required</h3>
                  <p className="text-red-700 text-xs mt-1 leading-relaxed">
                    This domain is not whitelisted in your Firebase project.
                  </p>
                  
                  <div className="mt-3 flex items-center gap-2 bg-white p-2 rounded-lg border border-red-100 shadow-sm relative">
                    <input 
                      readOnly
                      value={currentDomain}
                      className="text-[11px] font-mono text-red-900 flex-1 bg-transparent border-none focus:ring-0 p-0 w-full outline-none"
                      onClick={(e) => e.currentTarget.select()}
                    />
                    <button 
                      onClick={copyToClipboard}
                      className="p-1.5 hover:bg-red-50 rounded-md transition-colors text-red-600 bg-red-50/50 flex-shrink-0"
                      title="Copy Domain"
                    >
                      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  <p className="text-[10px] text-red-600/80 mt-2 font-medium">
                    1. Copy the domain above.<br/>
                    2. Go to <a href="https://console.firebase.google.com/" target="_blank" rel="noopener noreferrer" className="underline hover:text-red-800">Firebase Console</a> &gt; Authentication &gt; Settings &gt; Authorized Domains.<br/>
                    3. Add Domain and paste.
                  </p>

                  {onGuestLogin && (
                    <button 
                      onClick={onGuestLogin}
                      className="mt-4 w-full py-2 bg-red-100 hover:bg-red-200 text-red-800 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-2"
                    >
                      <UserCircle2 className="w-4 h-4" />
                      Ignore & Continue as Guest
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* General Error Display */}
          {error && !isDomainError && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-3 flex items-center gap-2 text-red-700 text-sm font-medium">
               <AlertCircle className="w-4 h-4 flex-shrink-0" />
               <span>{error}</span>
            </div>
          )}

          <div className="flex flex-col gap-4">
             <button
               type="button"
               onClick={handleLoginClick}
               disabled={isLoading}
               className="w-full h-[50px] bg-white border border-gray-300 rounded-full flex items-center justify-center gap-3 hover:bg-gray-50 hover:shadow-sm hover:scale-[1.01] active:scale-95 transition-all text-gray-700 font-medium text-base shadow-[0_2px_4px_rgba(0,0,0,0.05)] disabled:opacity-70 disabled:cursor-not-allowed"
             >
               {isLoading ? (
                 <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
               ) : (
                 <>
                   <svg className="w-6 h-6" viewBox="0 0 24 24">
                     <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                     <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                     <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                     <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                   </svg>
                   <span>Continue with Google</span>
                 </>
               )}
             </button>
          </div>
          
          <div className="text-center">
            <p className="text-[11px] text-gray-500 font-medium">
              By continuing, you agree to our Terms of Service.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
