
import React from 'react';

interface Props {
  progress: number;
  statusMessage: string;
}

export const NeumorphicProgressBar: React.FC<Props> = ({ progress, statusMessage }) => {
  return (
    <div className="w-full max-w-2xl mx-auto p-8 rounded-[32px] bg-[#f0f2f5] shadow-[20px_20px_60px_#ced1d6,-20px_-20px_60px_#ffffff] border border-white/20">
      <div className="flex justify-between items-end mb-4">
        <div className="text-left">
          <span className="text-[11px] font-extrabold uppercase tracking-[0.2em] text-gray-400 block mb-1">AI Cleaning Engine</span>
          <h3 className="text-blue-600 font-bold text-lg transition-all duration-300">{statusMessage}</h3>
        </div>
        <div className="text-right">
          <span className="text-3xl font-black text-gray-800 tabular-nums">{Math.round(progress)}%</span>
        </div>
      </div>

      {/* Neumorphic Track */}
      <div className="relative w-full h-8 bg-[#e0e5ec] rounded-2xl shadow-[inset_6px_6px_12px_#b8bec5,inset_-6px_-6px_12px_#ffffff] overflow-hidden p-1.5">
        {/* Animated Gradient Fill */}
        <div
          className="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-xl transition-all duration-300 ease-out shadow-[0_0_15px_rgba(37,99,235,0.3)] relative overflow-hidden"
          style={{ width: `${progress}%` }}
        >
          {/* Shine Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-[shine_2s_infinite]"></div>
        </div>
      </div>

      <style>{`
        @keyframes shine {
          0% { transform: translateX(-100%) skewX(-15deg); }
          100% { transform: translateX(200%) skewX(-15deg); }
        }
      `}</style>
    </div>
  );
};
