
export interface ImageFile {
  id: string;
  file: File;
  preview: string;
  processed?: string;
  status: 'idle' | 'detecting' | 'processing' | 'done' | 'error';
  mask?: string; // base64 mask if manual
  mode: 'ai' | 'manual';
  error?: string;
}

export type AppStage = 'landing' | 'editing' | 'processing' | 'results';

export interface BoundingBox {
  ymin: number;
  xmin: number;
  ymax: number;
  xmax: number;
}

// Added User interface to fix import error in services/auth.ts
export interface User {
  uid: string;
  name: string;
  email: string;
  avatar: string;
  hasApiKey: boolean;
  sessionApiKey?: string;
}
