
import { User } from '../types';
import { auth, db } from './firebase';
import { GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";

// --- Types ---
interface FirestoreUserData {
  email: string;
  name: string;
  avatar: string;
  geminiApiKey?: string;
  updatedAt: string;
}

// --- Session Management ---

/**
 * Listens for auth state changes from Firebase.
 * This is the source of truth for whether a user is logged in.
 */
export const subscribeToAuthChanges = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, async (firebaseUser) => {
    if (!firebaseUser) {
      callback(null);
      return;
    }

    // User is logged in, now fetch their API Key from Firestore
    try {
      const userDocRef = doc(db, "users", firebaseUser.uid);
      const userDocSnap = await getDoc(userDocRef);
      
      let apiKey: string | undefined = undefined;

      if (userDocSnap.exists()) {
        const data = userDocSnap.data() as FirestoreUserData;
        apiKey = data.geminiApiKey;
      }

      const user: User = {
        uid: firebaseUser.uid,
        name: firebaseUser.displayName || "User",
        email: firebaseUser.email || "",
        avatar: firebaseUser.photoURL || "",
        hasApiKey: !!apiKey,
        sessionApiKey: apiKey
      };

      callback(user);
    } catch (error) {
      console.error("Error fetching user data:", error);
      // Fallback if database fails: show user as logged in but without key
      callback({
        uid: firebaseUser.uid,
        name: firebaseUser.displayName || "User",
        email: firebaseUser.email || "",
        avatar: firebaseUser.photoURL || "",
        hasApiKey: false
      });
    }
  });
};

/**
 * Log in using Firebase Google Auth Popup.
 * This avoids manual Client ID configuration and simplifies origin handling.
 */
export const loginWithGoogle = async (): Promise<void> => {
  try {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  } catch (error) {
    console.error("Firebase Sign-In Error:", error);
    throw error;
  }
};

/**
 * Log out the current user.
 */
export const logoutUser = async (): Promise<void> => {
  await signOut(auth);
};

/**
 * Save the API Key to Firestore under the user's document.
 */
export const validateAndStoreApiKey = async (apiKey: string): Promise<boolean> => {
  // Basic validation
  if (!apiKey.startsWith('AIza') || apiKey.length < 20) {
      throw new Error("Invalid API Key format");
  }

  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error("No user logged in");

  try {
    const userDocRef = doc(db, "users", currentUser.uid);
    
    // Save to Firestore. 
    // merge: true ensures we don't overwrite other fields if they exist.
    await setDoc(userDocRef, {
      email: currentUser.email,
      name: currentUser.displayName,
      avatar: currentUser.photoURL,
      geminiApiKey: apiKey,
      updatedAt: new Date().toISOString()
    }, { merge: true });

    return true;
  } catch (error) {
    console.error("Error saving API Key to DB:", error);
    throw new Error("Failed to save API Key to database.");
  }
};
