
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBwy8z-t9pO2uvPCr9ruJMnrf1r-ECitiQ",
  authDomain: "nano-erase.firebaseapp.com",
  projectId: "nano-erase",
  storageBucket: "nano-erase.firebasestorage.app",
  messagingSenderId: "988124477771",
  appId: "1:988124477771:web:6a51acdc8a9e8b718b90ce",
  measurementId: "G-Q7EDJXCFHW"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export Auth and Firestore services
export const auth = getAuth(app);
export const db = getFirestore(app);
